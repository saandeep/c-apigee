var express = require('express');
var usergrid = require('usergrid');
var url = require('url');

var app = new express();
var client = new usergrid.client({
    orgName:'cosafinity',
    appName:'sandbox',
    URI:'https://api.usergrid.com',
    //authType:usergrid.AUTH_APP_USER,
    logging: true, //optional - turn on logging, off by default
    buildCurl: true //optional - turn on curl commands, off by default
});

app.get('/:user/lists/:listname/products',function(req,res){
  //Get Stores from usergrid
  var options = {'method':'GET','endpoint':'users/' + req.headers['userid'] + '/lists_' + req.params.listname + '/products'};
  client.request(options,function(error,response){
		if(!error){
			res.writeHead(200, {'Content-Type':'application/json'}) ;
			res.end(JSON.stringify(response));
		}else{
			res.writeHead(500,{'Content-Type':'application/json'});
			res.end(JSON.stringify(options));
		}
  });

});

app.post('/:user/lists/:listname/products/:productid',function(req,res){
  //Get Stores from usergrid
  var options = {'method':'POST', 'endpoint':'users/' + req.headers['userid']  + '/lists_' + req.params.listname + "/products/" + req.params.productid};
  client.request(options,function(error,response){
		if(!error){
			res.writeHead(200, {'Content-Type':'application/json'}) ;
			res.end(JSON.stringify(response));
		}else{
			res.writeHead(500,{'Content-Type':'application/json'});
			res.end(JSON.stringify(options));
		}
  });

});

app.listen(3000);
