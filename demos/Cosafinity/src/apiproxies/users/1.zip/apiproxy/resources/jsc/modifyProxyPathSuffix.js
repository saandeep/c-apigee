var userid=context.getVariable("accesstoken.userid");

var modifiedPathsuffx = userid;

var pathsuffix = context.getVariable("proxy.pathsuffix");
if(pathsuffix.indexOf("feed") != -1){
	modifiedPathsuffx = modifiedPathsuffx + "/feed" ;
}
var targeturl = context.getVariable("target.url");
context.setVariable("target.url",targeturl + "/" + modifiedPathsuffx);