#! /usr/local/bin/node
/*jslint node:true */

// runLoad.js
// ------------------------------------------------------------------
//
// Run a set of REST requests from Node, as specified in a job
// definition file. This is to generate load for API Proxies.
//
// This script uses various npm modules. You may need to do the
// following to get pre-requisites before running this script:
//
//   npm install
//
// There is an API for this target.
//
// GET /status
//   returns a json payload providing status of the service.
//   Keep in mind the status is for the nodejs logic on a single MP only.
//   There are typically multiple MPs, so invoking GET /status multiple
//   times in succession will likely deliver different results.
//
// POST /control
//   pass a x-www-form-urlencoded payload with action=start or action=stop
//   to start or stop the load being emitted from the nodejs script.
//   You need to send this request just once, to stop all MPs
//   that are generating load.  use this header:
//        Content-type: application/x-www-form-urlencoded
//
//
// created: Wed Jul 17 18:42:20 2013
// last saved: <2014-December-05 14:04:54>
// ------------------------------------------------------------------
//
// Copyright ¬© 2013, 2014 Dino Chiesa and Apigee Corp
// All rights reserved.
//
// ------------------------------------------------------------------

var assert = require('assert'),
    http = require('http'),
    q = require ('q'),
    request = require('./slimNodeHttpClient.js'),
    express = require('express'),
    fs = require('fs'),
    apigee = require('apigee-access'),
    cache = apigee.getCache(undefined, {scope: 'application'}), // get the default cache
    gCacheKey,
    WeightedRandomSelector = require('./weightedRandomSelector.js'),
    app = express(),
    globalTimeout = 8000, // in ms
    defaultRunsPerHour = 60,
    oneHourInMs = 60 * 60 * 1000,
    minSleepTimeInMs = 1200,
    ipForCities = 'https://api.usergrid.com/mukundha/testdata/cities',
    citiesAndPopulation = 'https://api.usergrid.com/dino/loadgen1/cities',
    log = new Log(),
    isUrl = new RegExp('^https?://[-a-z0-9\\.]+($|/)', 'i'),
    wantMasking = true,
    gModel,
    gStatus = {
      loadGenVersion: "Friday,  5 December 2014, 14:24",
      times : {
        start : (new Date()).toString(),
        lastRun : (new Date()).toString(),
      },
      nCycles : 0,
      nRequests : 0,
      jobId : '',
      description : '',
      status : "none",
      responseCounts : { total: 0}
    },
    globals = {},
    rStringChars = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';


function Log(id) { }

Log.prototype.write = function(str) {
  var time = (new Date()).toString(), me = this;
  console.log('[' + time.substr(11, 4) + '-' +
              time.substr(4, 3) + '-' + time.substr(8, 2) + ' ' +
              time.substr(16, 8) + '] ' + str );
};

function randomString(length) {
  var i, result = '';
  length = length || Math.ceil((Math.random() * 28)) + 12;
    for (i = length; i > 0; --i) {
      result += rStringChars[Math.round(Math.random() * (rStringChars.length - 1))];
    }
    return result;
}

function randomName() {
  return selectGivenName() + '-' +
    Math.floor((Math.random() * 10000));
}

function selectGivenName() {
  var names = ['Ashish', 'Nikhil', 'Seshadri', 'Kyle', 'Jeff', 'Neha', 'Jin', 'Lewis', 'Fernando', 'Rajeev', 'Mary', 'Sophia', 'Rose', 'Julianna', 'Grace', 'Janice', 'Niko'],
  n = names[Math.floor((Math.random() * names.length))];
  return n;
}

function copyHash(obj) {
  var copy = {};
  if (null !== obj && typeof obj == "object") {
    for (var attr in obj) {
      if (obj.hasOwnProperty(attr)) {copy[attr] = obj[attr];}
    }
  }
  return copy;
}

function trackFailure(e) {
  if (e) {
    log.write('failure: ' + e);
    log.write(e.stack);
    gStatus.lastError = {
      message: e.stack.toString(),
      time: (new Date()).toString()
    };
  }
  else {
    log.write('unknown failure?');
  }
}

function getType(obj) {
  return Object.prototype.toString.call(obj);
}

function logTransaction(e, req, res, obj, payload) {
  console.log('\n' + req.method + ' ' + req.path);
  console.log('headers: ' + JSON.stringify(req._headers, null, 2));
  if (payload) {
    console.log('payload: ' + JSON.stringify(payload, null, 2));
  }
  console.log('\nresponse status: ' + res.statusCode);
  console.log('response body: ' + JSON.stringify(obj, null, 2) +'\n\n');
  assert.ifError(e);
}

function maskToken(value) {
  if ( ! wantMasking) {return value;}
  var re1;
  if ( ! startsWith(value, 'Bearer ')) return value;
  return 'Bearer *******';
}

function startsWith (str, frag){
  return str.slice(0, frag.length) == frag;
}


// function cacheKey(httpRequest) {
//   var varnames = [ 'apiproxy.name', 'apiproxy.revision' ],
//       values = varnames.map(function(v, ix){
//         return apigee.getVariable(httpRequest, v);
//       }),
//       key = 'runload-status-' + values.join('-');
//   // side effect - set these global vars
//   if ( ! gOrg) {
//     gOrg = apigee.getVariable(httpRequest, 'organization.name');
//   }
//   if ( ! gEnv) {
//     gEnv = apigee.getVariable(httpRequest, 'environment.name');
//   }
//   return key;
// }


function retrieveCities(ctx) {
  var deferredPromise = q.defer(),
      options = {
        timeout : 66000, // in ms
        uri: citiesAndPopulation + '?limit=350',
        method: 'get',
        headers: {
          'Accept' : 'application/json',
          'user-agent' : 'SlimHttpClient/1.0'
        }
      };

  log.write('retrieveCities');

  request(options, function(e, httpResp, body) {
    var a, type, cities;
    if (e) {
      log.write('retrieveCities, error: ' + e);
    }
    else {
      type = getType(body);
      if (type === "[object String]") {
        try {
          body = JSON.parse(body);
          cities = body.entities.map(function(elt) {
            return [ elt, Number(elt.pop2010) ];
          });
          globals.citySelector = new WeightedRandomSelector(cities);
        }
        catch(exc1) {
          log.write('retrieveCities: cannot parse body :(');
        }
      }
      log.write('retrieveCities done');
    }
    deferredPromise.resolve(ctx);
  });
  return deferredPromise.promise;
}


function chooseRandomIpFromRecord(rec) {
  var ranges, numRanges, selectedRange,
      start, end, index,
      selected, w, x, y, z, allGood;
  if ( ! rec) { return null;}

  // It's possible we'll get bad data from the request, in which case
  // rec.ranges may be invalid. Or, any of the other successive fields
  // may be invalid. In that case, bail.
  allGood = (ranges = rec.ranges) &&
    (numRanges = ranges.length) &&
    (selectedRange = ranges[Math.floor(Math.random() * numRanges)]) &&
    (start = parseInt(selectedRange[0], 10)) &&
    (end = parseInt(selectedRange[1], 10)) &&
    (index = Math.floor(Math.random()*(start-end))) &&
    (selected = start + index) &&
    (w =  Math.floor(( selected / 16777216 ) % 256)) &&
    (x =  Math.floor(( selected / 65536    ) % 256)) &&
    (y =  Math.floor(( selected / 256      ) % 256)) &&
    (z =  Math.floor(( selected            ) % 256));

  if (allGood)
    return w + "." + x + "." + y + "." + z ;

  return null;
}


function contriveIpAddress(context) {
  var city, ql, options, deferred, choose = function() {
        context.job.contrivedIp = chooseRandomIpFromRecord(globals.cities[city.name]);
        context.job.chosenCity = city.name;
        log.write('contriveIpAddress: ' + city.name + ' ' + context.job.contrivedIp);
      };

  log.write('contriveIpAddress');
  if (!globals.citySelector) {
    return context;
  }

  city = globals.citySelector.select()[0];

  log.write('contriveIpAddress: city: ' + city.name);

  if (globals.hasOwnProperty('cities') && globals.cities[city.name]) {
    // the selected city has been cached.
    choose();
    return context;
  }

  // must do a lookup
  ql = "select * where city='" + city.name + "'";
  options = {
    timeout : 16000, // in ms
    uri : ipForCities + '?ql=' + encodeURIComponent(ql),
    method: 'get',
    headers: {
      'Accept' : 'application/json',
      'user-agent' : 'SlimHttpClient/1.0'
    }
  };
  deferred = q.defer();

  request(options, function(e, httpResp, body) {
    var type;
    if (e) {
      log.write('contriveIpAddress, error: ' + e);
    }
    else {
      type = Object.prototype.toString.call(body);
      if (type === "[object String]") {
        try {
          body = JSON.parse(body);
        }
        catch(exc1) {
          log.write('contriveIpAddress: cannot parse body :(');
        }
      }
      if (body.entities && body.entities[0]) {
        if (!globals.cities) {globals.cities = {}; }
        globals.cities[city.name] = body.entities[0];
        choose();
      }
      else {
        log.write('contriveIpAddress: no body entities');
      }
    }
    deferred.resolve(context);
  });
  return deferred.promise;
}


function resolveNumeric(input) {
  var I = input;
  if (typeof input == "undefined") {
    I = 1;
  }
  else if (typeof input == "string") {
    I = eval('(' + input + ')');
  }
  return I;
}


function evalTemplate(ctx, code) {
  var src = '(function (', c = 0, f, values = [], result,
      extractContext = ctx.state.extracts;

  // log.write('eval: ' + code);
  // log.write('ctx: ' + JSON.stringify(extractContext, null, 2));
  // TODO: cache this?
  // create the fn signature
  for (var prop in extractContext) {
    if (extractContext.hasOwnProperty(prop)) {
      if (c > 0) {src += ',';}
      src += prop;
      values.push(extractContext[prop]);
      c++;
    }
  }
  src += '){return ' + code + ';})';
  log.write('evalTemplate: ' + src);
  try {
    f = eval(src);
    // call the function with all its arguments
    result = f.apply(null, values);
  }
  catch (exc1) {
    r = null;
  }
  return result;
}

// expandEmbeddedTemplates: walks through an object, replacing each embedded
// template as appropriate. This is used to expand a templated payload.
function expandEmbeddedTemplates(ctx, obj) {
  var re1 = new RegExp('(.*)(?!{{){([^{}]+)(?!}})}(.*)'),
      re2 = new RegExp('(.*){{([^{}]+)}}(.*)'), // for double-curlies
      newObj = {}, match, newVal,
      type = Object.prototype.toString.call(obj), x, i;
  if (type === "[object Array]") {
    // iterate
    newObj = [];
    for (i=0; i<obj.length; i++) {
      x = expandEmbeddedTemplates(ctx, obj[i]);
      newObj.push(x);
    }
  }
  else if (type === "[object Object]") {
    for (var prop in obj) {
      if (obj.hasOwnProperty(prop)) {
        type = Object.prototype.toString.call(obj[prop]);
        if (type === "[object String]") {
          // replace all templates in the string
          for (newVal = obj[prop], match = re1.exec(newVal); match; match = re1.exec(newVal)){
            newVal = match[1] + evalTemplate(ctx, match[2]) + match[3];
          }
          for (match = re2.exec(newVal); match; match = re2.exec(newVal)){
            newVal = match[1] + '{' + match[2] + '}' + match[3];
          }

          newObj[prop] = newVal;
        }
        else if (type === "[object Array]") {
          // iterate
          newObj[prop] = [];
          for (i=0; i<obj[prop].length; i++) {
            x = expandEmbeddedTemplates(ctx, obj[prop][i]);
            newObj[prop].push(x);
          }
        }
        else if (type === "[object Object]") {
          // recurse
          newObj[prop] = expandEmbeddedTemplates(ctx, obj[prop]);
        }
        else {
          // no replacement
          newObj[prop] = obj[prop];
        }
      }
    }
  }
  return newObj;
}


// ==================================================================

function invokeOneRequest(context) {
  var re = new RegExp('(.*){(.+)}(.*)'),
      state = context.state,
      job = context.job,
      sequence = job.sequences[state.sequence],
      req = sequence.requests[state.request],
      url = req.url || req.pathSuffix,
      match = re.exec(url),
      actualPayload,
      headers = (job.defaultProperties && job.defaultProperties.headers) ? job.defaultProperties.headers : {},
      reqOptions = { headers: headers},
      p = q.resolve(context);

  log.write(job.id + ' invokeOneRequest');

  // 1. delay as appropriate
  if (req.delayBefore) {
    p = p.then(function(ctx){
      var deferredPromise = q.defer(),
          t = resolveNumeric(req.delayBefore);
      setTimeout(function() { deferredPromise.resolve(ctx); }, t);
      return deferredPromise.promise;
    });
  }

  // 2. run any imports.
  if (req.imports && req.imports.length>0) {
    p = p.then(function(ctx){
      var imp, i, L;
      // cache the eval'd import functions
      for (i=0, L=req.imports.length; i<L; i++) {
        imp = req.imports[i];
        if ( ! imp.compiledFn) {
          log.write('eval: ' + imp.fn);
          imp.compiledFn = eval('(' + imp.fn + ')');
        }
        log.write(imp.description);
        // actually invoke the compiled fn
        try {
          ctx.state.extracts[imp.valueRef] = imp.compiledFn(ctx.state.extracts);
          log.write(imp.valueRef + ':=' + JSON.stringify(ctx.state.extracts[imp.valueRef]));
        }
        catch (exc1) {
          ctx.state.extracts[imp.valueRef] = null;
          log.write(imp.valueRef + ':= null (exception: ' + exc1 + ')');
        }
      }
      return ctx;
    });
  }

  // 3. evaluate the url path if required.
  if (match) {
    // The url includes at least one template.
    // Must do replacements within the promise chain.
    p = p.then(function(ctx){
      // there may be multiple templates; must evaluate all of them
      var v = url;
      for (; match && v; match = re.exec(v)) {
        v = evalTemplate(ctx, match[2]);
        v = (v) ? (match[1] + v + match[3]) : null;
      }
      url = v ? v : "";
      return ctx;
    });
  }

  // 4. conditionally set additional headers for this request.
  if (req.headers) {
    p = p.then(function(ctx) {
      var match, value;
      for (var hdr in req.headers) {
        if (req.headers.hasOwnProperty(hdr)) {
          value = req.headers[hdr];
          match = re.exec(value);
          if (match) {
            // replace all templates until done
            for (; match; match = re.exec(value)) {
              value = match[1] + evalTemplate(ctx, match[2]) + match[3];
            }
          }
          else {
            value = req.headers[hdr];
          }
          log.write('Header ' + hdr + ': ' + maskToken(value) );
          reqOptions.headers[hdr.toLowerCase()] = value;
        }
      }
      return ctx;
    });
  }

  // 5. actually do the http call, and run the subsequent extracts
  p = p.then(function(ctx) {
    var deferredPromise = q.defer(),
        city,
        method = (req.method)? req.method.toLowerCase() : "get",
        respCallback = function(e, httpResp, body) {
          var i, L, ex, obj, aIndex;
          gStatus.nRequests++;
          if (e) {
            log.write(e);
          }
          else {
            log.write(httpResp.statusCode);
            // keep a count of status codes
            aIndex = httpResp.statusCode + '';
            if (gStatus.responseCounts.hasOwnProperty(aIndex)) {
              gStatus.responseCounts[aIndex]++;
            }
            else {
              gStatus.responseCounts[aIndex] = 1;
            }
            gStatus.responseCounts.total++;
            if (req.extracts && req.extracts.length>0) {
              // cache the eval'd extract functions
              // if ( ! ctx.state.extracts) { ctx.state.extracts = {}; }
              for (i=0, L=req.extracts.length; i<L; i++) {
                ex = req.extracts[i];
                if ( ! ex.compiledFn) {
                  log.write('eval: ' + ex.fn);
                  ex.compiledFn = eval('(' + ex.fn + ')');
                }
                log.write(ex.description);
                // actually invoke the compiled fn
                try {
                  // sometimes the body is already parsed into an object?
                  obj = Object.prototype.toString.call(body);
                  if (obj === '[object String]') {
                    try {
                      obj = JSON.parse(body);
                    }
                    catch (exc1){
                      // possibly it was not valid json
                      obj = null;
                    }
                  }
                  else {
                    obj = body;
                  }
                  ctx.state.extracts[ex.valueRef] = ex.compiledFn(obj, httpResp.headers, ctx.state.extracts);
                  log.write(ex.valueRef + ':=' + JSON.stringify(ctx.state.extracts[ex.valueRef]));
                }
                catch (exc1) {
                  ctx.state.extracts[ex.valueRef] = null;
                  log.write(ex.valueRef + ':= null (exception: ' + exc1 + ')');
                }
              }
            }
          }
          ctx.state.request++;
          deferredPromise.resolve(ctx);
        };

    reqOptions.method = method;
    reqOptions.timeout = globalTimeout;
    reqOptions.followRedirects = false;

    if (isUrl.test(url)) {
      // if it is a complete URL, use it.
      reqOptions.uri = url;
    }
    else if (job.defaultProperties.port) {
      // Url.parse (used by slimhttpclient) is sort of broken.  if the
      // URL specifies the standard port (eg 80 for http), then the Url
      // gets parsed strangely. Therefore, clients must include the port
      // only if it is non-standard.
      reqOptions.uri =
        job.defaultProperties.scheme + '://' +
        job.defaultProperties.host;

      if (((job.defaultProperties.port !== 80) &&
           (job.defaultProperties.scheme.toLowerCase() === 'http')) ||
          ((job.defaultProperties.port !== 443) &&
           (job.defaultProperties.scheme.toLowerCase() === 'https'))){
        reqOptions.uri += ':' + job.defaultProperties.port;
      }

      reqOptions.uri += url;
    }
    else {
      reqOptions.uri =
        job.defaultProperties.scheme + '://' + job.defaultProperties.host + url;
    }

    // var parsedUrl = Url.parse(reqOptions.uri);
    // log.write('parsed URL :' + JSON.stringify(parsedUrl, null, 2));

    if (job.hasOwnProperty('contrivedIp') && job.contrivedIp) {
      reqOptions.headers['x-random-city'] = job.chosenCity;
      reqOptions.headers['x-forwarded-for'] = job.contrivedIp;
    }
    else {
      log.write('no contrived IP');
    }

    log.write(method + ' ' + reqOptions.uri);

    if (method === "post" || method === "put") {
      actualPayload = expandEmbeddedTemplates(ctx, req.payload);
      reqOptions.json = actualPayload;
      request(reqOptions, respCallback);
    }
    else if (method === "get" || method === "delete") {
      request(reqOptions, respCallback);
    }
    else {
      assert.fail(r.method,"get|post|put|delete", "unsupported method", "<>");
    }
    return deferredPromise.promise;
  });

  return p;
}



// ==================================================================

function reportModel (context) {
  console.log('================================================');
  console.log('==         Job Definition Retrieved           ==');
  console.log('================================================');
  console.log(JSON.stringify(context, null, 2));
  return context;
}


function setInitialContext(ctx) {
  gStatus.status = "initializing";
  return { job: ctx };
}

// xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

function runJob(context) {
  var state = context.state,
      job = context.job,
      p, sequence;

  // This is an unrolled version of a 3-level-deep nested loop
  if (state.request === state.R) {
    state.request = 0;
    state.iteration++;
    log.write('++ Iteration');
    return q.resolve(context).then(runJob);
  }
  if ( !state.I[state.sequence] && state.sequence < state.S) {
    state.I[state.sequence] = resolveNumeric(job.sequences[state.sequence].iterations);
  }
  if (state.I[state.sequence] && state.iteration === state.I[state.sequence]) {
    state.iteration = 0;
    state.sequence++;
    log.write('++ Sequence');
    return q.resolve(context).then(runJob, trackFailure);
  }
  if (state.sequence === state.S) {
    // No more work to do. Terminate this sequence.
    state.sequence = 0;
    return q(context).then(setWakeup, trackFailure);
  }

  // Need to verify that all properties are valid.
  // Sometimes they are not due to intermittent data retrieval errors.
  // In which case, just sleep and try again at next interval.
  if ( ! (job.sequences && job.sequences.length && (state.sequence < job.sequences.length) &&
          job.sequences[state.sequence].requests && job.sequences[state.sequence].requests.length)) {
            return q.resolve(context)
      .then(function(c){
        log.write('state error');
        return c;
      })
      .then(setWakeup);
  }

  // set and log counts
  state.S = job.sequences.length;
  state.R = job.sequences[state.sequence].requests.length;
  if ( ! state.I[state.sequence]) {
    state.I[state.sequence] = resolveNumeric(job.sequences[state.sequence].iterations);
  }
  log.write('R ' + (state.request + 1) + '/' + state.R +
            ' I ' + (state.iteration + 1) + '/' + state.I[state.sequence] +
            ' S ' + (state.sequence + 1) + '/' + state.S);


  // if we arrive here we're doing a request, implies an async call
  p = q.resolve(context);

  // generate a random IP address if necessary
  if (state.request === 0 && state.iteration === 0 && state.sequence === 0) {
    if (!job.hasOwnProperty('geoDistribution') || job.geoDistribution == 1) {
      if (!globals.citySelector) {
        p = p.then(retrieveCities, trackFailure);
      }
      p = p.then(contriveIpAddress, trackFailure);
      // Upon failure, no job.contrivedIp gets set in context.
      // This is ok, though. We can still continue.
    }
    else {
      p = p.then(function(ctx){
        log.write('no geo distribution');
      });
    }
  }

  // do the call
  p = p.then(invokeOneRequest, trackFailure);

  // sleep if necessary
  sequence = job.sequences[state.sequence];
  if (state.request === 0 && state.iteration !== 0) {
    if (sequence.delayBetweenIterations) {
      p = p.then(function(ctx){
        var deferredPromise = q.defer(),
            t = resolveNumeric(sequence.delayBetweenIterations);
        setTimeout(function() { deferredPromise.resolve(ctx); }, t);
        return deferredPromise.promise;
      });
    }
  }

  return p.then(runJob);
}


function initializeJobRunAndKickoff(context) {
  var now = (new Date()).valueOf(),
    // initialize context for running
      newState = {
        state:'run',
        sequence : 0,
        S : context.job.sequences.length,
        request : 0,
        R : context.job.sequences[0].requests.length,
        iteration : 0,
        I : [],
        extracts: copyHash(context.job.initialContext),
        start : now
      };

  gStatus.jobId = context.job.id || "-none-";
  gStatus.description = context.job.description || "-none-";

  // if (gStatus.status == "pending-stop") {
  //   log.write(gStatus.jobId + ' no launch - pending stop');
  //   gStatus.status = "stopped";
  //   return context;
  // }

  // launch the loop
  gStatus.status = "running";

  context.state = newState;

  return q(context)
    .then(runJob);
}



function setWakeup(context) {
  var job = context.job,
      jobid = job.id,
      now = new Date(),
      wakeTime,
      currentHour = now.getHours(),
      currentDayOfWeek = now.getDay(),
      durationOfLastRun = now - context.state.start,
      runsPerHour, sleepTimeInMs;

  log.write('setWakeup');
  gStatus.nCycles++;
  gStatus.times.lastRun = now.toString();

  // compute and validate the sleep time
  if (currentHour < 0 || currentHour > 23) { currentHour = 0;}
  runsPerHour = (job.invocationsPerHour &&
                 job.invocationsPerHour[currentHour]) ?
    job.invocationsPerHour[currentHour] : defaultRunsPerHour;

  // variation by day of week
  if (job.variationByDayOfWeek &&
                 job.variationByDayOfWeek.length &&
                 job.variationByDayOfWeek.length == 7 &&
                 job.variationByDayOfWeek[currentDayOfWeek] &&
                 job.variationByDayOfWeek[currentDayOfWeek] > 0 &&
                 job.variationByDayOfWeek[currentDayOfWeek] <= 2) {
    runsPerHour *= job.variationByDayOfWeek[currentDayOfWeek];
  }

  log.write(jobid + ' duration of last run: ' + durationOfLastRun);
  sleepTimeInMs =
    Math.floor(oneHourInMs / runsPerHour) - durationOfLastRun;

  if (sleepTimeInMs < minSleepTimeInMs) { sleepTimeInMs = minSleepTimeInMs; }

  log.write(jobid + ' ' + runsPerHour + ' runs per hour');
  wakeTime = new Date(now.valueOf() + sleepTimeInMs);
  log.write(jobid + ' sleep ' + sleepTimeInMs + 'ms, wake at ' +
            wakeTime.toString().substr(16, 8));

  gStatus.durationOfLastRunInMs = durationOfLastRun;
  gStatus.currentRunsPerHour = runsPerHour;
  gStatus.status = "waiting";
  gStatus.times.wake = wakeTime.toString();

  // now, sleep. On wakeup, either run... or sleep again.
  setTimeout(function () {
    log.write(jobid + ' awake');
    delete gStatus.times.wake;
    cache.get(gCacheKey, function(e, value) {
      log.write(jobid + (e ? ' cannot retrieve status.' : ' cached status: ' + value));
      gStatus.cachedStatus = value || '-none-';
      if (e || value != "stopped") {
        // failed to get a value, or value is not stopped
        q({job:job})
          .then(initializeJobRunAndKickoff)
          .done(function(){},
                function(e){
                  log.write('unhandled error: ' + e);
                  log.write(e.stack);
                });
      }
      else {
        // value is stopped. Sleep one cycle, then check again.
        context.state.start = new Date(); // now
        q(context).then(setWakeup, trackFailure);
      }
    });
  }, sleepTimeInMs);
  return context;
}



// xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

function kickoff(arg) {
  try {
    if (fs.existsSync(arg)) {
      console.log(arg);
      gModel = JSON.parse(fs.readFileSync(arg, "utf8"));
      if ( ! gModel.id) {
        throw "you must specify a unique id for the job";
      }
      gCacheKey = 'runload-status-' + gModel.id;
      gStatus.cacheKey = gCacheKey;
      q(gModel)
        //.then(reportModel)
        .then(setInitialContext)
        .then(initializeJobRunAndKickoff)
        .done(function() {}, function(e) {
          log.write('unhandled error: ' + e);
          log.write(e.stack);
        });
    }
    else {
      console.log("That file does not exist");
    }
  }
  catch (exc1) {
    console.log("Exception:" + exc1);
    console.log(exc1.stack);
  }
}

// =======================================================
//
// The simple API exposed by this script allows start, stop,
// and status query .
//
// =======================================================

app.use(express.urlencoded());

app.get('/status', function(request, response) {
  var payload;
  response.header('Content-Type', 'application/json');
  gStatus.times.current = (new Date()).toString();
  payload = copyHash(gStatus);
  cache.get(gCacheKey, function(e, value) {
    if (e) {
      payload.error = true;
      payload.cacheException = e.toString();
      response.send(500, JSON.stringify(payload, null, 2) + "\n");
    }
    else {
      payload.cachedStatus = value || '-none-';
      response.send(200, JSON.stringify(payload, null, 2) + "\n");
    }
  });
});


app.post('/control', function(request, response) {
  var payload,
      // post body parameter, or query param
      action = request.body.action || request.query.action,
      putCallback = function(e) {
        cache.get(gCacheKey, function(e, value) {
          if (e) {
            payload.error = true;
            payload.cacheException = e.toString();
            response.send(500, JSON.stringify(payload, null, 2) + "\n");
          }
          else {
            payload.cachedStatus = value;
            response.send(200, JSON.stringify(payload, null, 2) + "\n");
          }
        });
      };

  response.header('Content-Type', 'application/json');
  payload = copyHash(gStatus);
  payload.times.current = (new Date()).toString();

  if (action != "stop" && action != "start") {
    payload.error = "unsupported request (action)";
    response.send(400, JSON.stringify(payload, null, 2) + "\n");
    return;
  }

  cache.get(gCacheKey, function(e, value) {
    if (e) {
      payload.error = true;
      payload.cacheFail = true;
      payload.cacheException =  e.toString();
      response.send(500, JSON.stringify(payload, null, 2) + "\n");
    }
    else {
      payload.cachedStatus = value;
      if (value == "stopped") {
        if (action == "stop") {
          // nothing to do...send a 400.
          payload.error = "already stopped";
          response.send(400, JSON.stringify(payload, null, 2) + "\n");
        }
        else {
          // action == start
          cache.put(gCacheKey, "running", 8640000, putCallback);
        }
      }
      else {
        // is marked "running" now.
        if (action == "stop") {
          cache.put(gCacheKey, "stopped", 8640000, putCallback);
        }
        else {
          // action == start
          // nothing to do, send a 400.
          payload.error = "already running";
          response.send(400, JSON.stringify(payload, null, 2) + "\n");
        }
      }
    }
  });
});


// default behavior
app.all(/^\/.*/, function(request, response) {
  response.header('Content-Type', 'application/json');
  response.send(404, '{ "status" : "This is not the server you\'re looking for." }\n');
});


port = process.env.PORT || 5950;
app.listen(port, function() {
  setTimeout(function() { return kickoff("model.json"); }, 1200);
});
